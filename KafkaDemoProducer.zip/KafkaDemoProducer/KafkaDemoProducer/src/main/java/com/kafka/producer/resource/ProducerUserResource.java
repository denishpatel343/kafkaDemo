package com.kafka.producer.resource;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kafka.example.model.User;

@RestController
@RequestMapping(value="kafka")
public class ProducerUserResource {
	
	@Autowired
	KafkaTemplate<String,User> kafkat;
	private final String TOPIC="testKafka";
	
@GetMapping(value="/publish/{message}")
public String post(@PathVariable("message") final String message) {
	
	
	kafkat.send(TOPIC,new User(message,"Technology",12000D));
	
	return "Message has been published successfully";
	
	
	
}

}
