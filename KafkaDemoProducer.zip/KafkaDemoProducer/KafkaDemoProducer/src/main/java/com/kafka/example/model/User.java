package com.kafka.example.model;

public class User {

	 String name;
	 String Department;
	 Double salary;
	public User(String name, String department, Double salary) {
		super();
		this.name = name;
		Department = department;
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return Department;
	}
	public void setDepartment(String department) {
		Department = department;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	

	
}
